package si.um.feri.aiv.dao;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import si.um.feri.aiv.vao.Patient;

import java.util.List;

@Stateless
public class PatientDaoJpa implements PatientDao {

    @PersistenceContext(unitName = "patient-jpa")
    private EntityManager em;

    @Override
    public List<Patient> getAll() {
        return em.createQuery("SELECT p FROM Patient p", Patient.class).getResultList();
    }

    @Override
    public void add(Patient p) {
        if (p.getId() == null || em.find(Patient.class, p.getId()) == null) {
            em.persist(p);
        } else {
            em.merge(p); // update if exists
        }
    }

    @Override
    public void removeById(long id) {
        Patient p = em.find(Patient.class, id);
        if (p != null) em.remove(p);
    }

    @Override
    public Patient findById(long id) {
        return em.find(Patient.class, id);
    }
}
