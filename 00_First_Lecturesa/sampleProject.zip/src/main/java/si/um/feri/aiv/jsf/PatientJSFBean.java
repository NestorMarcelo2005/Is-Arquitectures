package si.um.feri.aiv.jsf;

import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import si.um.feri.aiv.dao.PatientDao;
import si.um.feri.aiv.ejb.PatientRemote;
import si.um.feri.aiv.vao.Patient;
import java.io.Serializable;
import java.util.List;

@Named("patientJSFBean")
@SessionScoped
public class PatientJSFBean implements Serializable {

    @EJB
    private PatientDao dao;
    @EJB
    private PatientRemote patientRemote;
    private Patient patient;
    private Long selectedPatientId;
    private boolean editMode;

    public PatientJSFBean(){
        patient = new Patient();
    }

    public void savePatient() {
        dao.add(patient);
        patient = new Patient();
        editMode = false;
    }

    public void prepareEdit(long id) {
        this.patient = dao.findById(id);
        this.editMode = true;
    }

    public void confirmDelete(long id) {
        selectedPatientId = id;
    }

    public void deleteConfirmedPatient() {
        if (selectedPatientId != null) {
            dao.removeById(selectedPatientId);
            selectedPatientId = null;
        }
    }

    public void cancelDelete() {
        selectedPatientId = null;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public boolean isEditMode() {
        return editMode;
    }

    public void setEditMode(boolean editMode) {
        this.editMode = editMode;
    }

    public Long getSelectedPatientId() {
        return selectedPatientId;
    }

    public void setSelectedPatientId(Long selectedPatientId) {
        this.selectedPatientId = selectedPatientId;
    }

    public List<Patient> getAllPatients() {
        return dao.getAll();
    }

    public List<Patient> getPatientsWithDoctor() {
        return patientRemote.findWithDoctor();

    }

    public List<Patient> getPatientsWithoutDoctor() {
        return patientRemote.findWithoutDoctor();
    }
}